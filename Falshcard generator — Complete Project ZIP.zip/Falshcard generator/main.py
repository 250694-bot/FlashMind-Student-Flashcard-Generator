"""Start the student login application."""
import tkinter as tk
from tkinter import messagebox
import sqlite3
from FlashMind_Student import AccountStore, LoginScreen

def main():
    root = tk.Tk()
    try:
        LoginScreen(root, AccountStore())
        root.mainloop()
    except (OSError, sqlite3.Error) as exc:
        messagebox.showerror('Cannot open project storage', str(exc))
        root.destroy()

if __name__ == '__main__':
    main()
