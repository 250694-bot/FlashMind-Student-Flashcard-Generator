# Falshcard generator

A local Python desktop mini project for student flashcards, multiple-choice quizzes and statistics.

**Student:** Uplakshya Gupta  
**Roll number:** 2501651530067  
**Submitted to:** Mrs. Prakanksha Shukla

## Start
1. Extract this folder to a writable location.
2. Install Python 3.10+ with Tkinter (included in the usual Windows python.org installer).
3. Open a terminal in the folder and run `python main.py`, or double-click Start-Windows.bat.
4. Create a student account, then sign in. No default credentials are supplied.

No pip packages are needed. requirements.txt documents this intentionally.

## Features
- Student registration, login, logout and separate account study files.
- Home dashboard with quiz attempts, card count, accuracy and recent results.
- Create, reveal, navigate, shuffle, delete, save and load flashcards.
- **New:** search questions/answers, edit cards and export a deck without credentials or history.
- Four-option quizzes with Easy/Medium/Hard filters, feedback and missed-answer review.
- Saved quiz history and aggregate statistics.
- Seven computer-science demo cards.

Cards are written manually; no AI generation is implemented. For high-quality quizzes, enter your own three wrong options. Otherwise, options may be borrowed from other cards. Cards without enough distinct options are skipped.

## Files
- main.py — recommended launch entry point (login first).
- FlashMind_Student.py — student account and dashboard module.
- FlashMind_Pro.py — study, quiz and statistics core.
- requirements.txt — dependency information.
- Start-Windows.bat — Windows launcher.
- docs/ — setup, user guide, project report, security notes and changelog.
- tests/test_project.py — automated logic tests.

## Data and backups
Student accounts and study files are created under flashmind_students/ at runtime. Back up that entire folder together. No real accounts or personal study files are included in this package. Load file can import your old JSON deck; save current work first because importing replaces cards/history. Deck export creates a shareable question/answer JSON list without quiz history or account details.

## Tests
Run `python -m unittest discover -s tests -v`.
Automated checks cover syntax, accounts, password hashing and quiz-option logic. They do not certify the graphical layout; manually follow docs/TESTING.md.

## Important limitations
This is a local student project, not production online security. Passwords are salted hashes, but study files are not encrypted. Local filesystem users can alter files. No password-reset, cloud sync or web backend is included. Running FlashMind_Pro.py directly bypasses login; use main.py for normal use.
