"""Headless logic checks: no GUI window or real student data created."""
import ast
import hashlib
import hmac
import random
import secrets
import sqlite3
import tempfile
import unittest
import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def load_logic():
    core = ast.parse((ROOT / 'FlashMind_Pro.py').read_text(encoding='utf-8'))
    student = ast.parse((ROOT / 'FlashMind_Student.py').read_text(encoding='utf-8'))
    ns = dict(random=random, uuid=uuid, Path=Path, hashlib=hashlib,
              hmac=hmac, secrets=secrets, sqlite3=sqlite3, DATA=ROOT,
              ITERATIONS=600000)
    nodes = [n for n in core.body if isinstance(n, ast.FunctionDef)]
    nodes += [n for n in student.body if isinstance(n, ast.ClassDef) and n.name == 'AccountStore']
    exec(compile(ast.Module(body=nodes, type_ignores=[]), 'logic', 'exec'), ns)
    return ns


class ProjectTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.logic = load_logic()

    def test_syntax_and_added_methods(self):
        for file in ROOT.glob('*.py'):
            ast.parse(file.read_text(encoding='utf-8'))
        tree = ast.parse((ROOT / 'FlashMind_Pro.py').read_text(encoding='utf-8'))
        app = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'FlashMind')
        methods = {n.name for n in app.body if isinstance(n, ast.FunctionDef)}
        self.assertTrue({'search_cards', 'edit_card', 'export_deck'} <= methods)

    def test_legacy_cards_and_generated_options(self):
        cards = self.logic['normalize_cards']([{'question': str(i), 'answer': str(i)} for i in range(4)])
        self.assertEqual(len({c['id'] for c in cards}), 4)
        for card in cards:
            options = self.logic['make_options'](card, cards)
            self.assertEqual(len(set(options)), 4)
            self.assertIn(card['answer'], options)
        self.assertIsNone(self.logic['make_options'](cards[0], cards[:1]))

    def test_custom_options_and_invalid_data(self):
        card = self.logic['normalize_cards']([{'question': 'Q', 'answer': 'A', 'wrong': ['B', 'C', 'D']}])[0]
        self.assertEqual(set(self.logic['make_options'](card, [card])), {'A', 'B', 'C', 'D'})
        with self.assertRaises(ValueError):
            self.logic['normalize_cards']([{'question': '', 'answer': 'A'}])

    def test_accounts(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = self.logic['AccountStore'](tmp)
            store.register('Student One', 'one', 'same-test-password')
            store.register('Student Two', 'two', 'same-test-password')
            first = store.authenticate('ONE', 'same-test-password')
            second = store.authenticate('two', 'same-test-password')
            self.assertNotEqual(first['id'], second['id'])
            self.assertIsNone(store.authenticate('one', 'wrong-password'))
            self.assertIsNone(store.authenticate('unknown', 'wrong-password'))
            with self.assertRaises(ValueError):
                store.register('Duplicate', 'one', 'test-password')
            with self.assertRaises(ValueError):
                store.register('Short Password', 'short', 'abc')
            with store.connect() as db:
                rows = db.execute('SELECT salt, digest FROM users').fetchall()
            self.assertNotEqual(rows[0][0], rows[1][0])
            self.assertNotEqual(rows[0][1], rows[1][1])
            self.assertEqual(len(rows[0][1]), 32)


if __name__ == '__main__':
    unittest.main()
