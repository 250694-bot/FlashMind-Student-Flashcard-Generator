"""Keep this file beside FlashMind_Pro.py. Run: python FlashMind_Student.py"""
import hashlib
import hmac
import secrets
import sqlite3
import time
import uuid
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox
import FlashMind_Pro as core

DATA = Path(__file__).resolve().parent / 'flashmind_students'
ITERATIONS = 600000


class AccountStore:
    def __init__(self, folder=DATA):
        self.folder = Path(folder)
        self.folder.mkdir(parents=True, exist_ok=True)
        with self.connect() as db:
            db.execute('CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY, username TEXT UNIQUE NOT NULL, name TEXT NOT NULL, salt BLOB NOT NULL, digest BLOB NOT NULL)')

    from contextlib import contextmanager

    @contextmanager
    def connect(self):
        db = sqlite3.connect(self.folder / 'accounts.sqlite3')
        try:
            with db:
                yield db
        finally:
            db.close()

    def register(self, name, username, password):
        name, username = name.strip(), username.strip().lower()
        if not 2 <= len(name) <= 80:
            raise ValueError('Name must contain 2–80 characters.')
        if not 3 <= len(username) <= 32 or not all(c in 'abcdefghijklmnopqrstuvwxyz0123456789_-' for c in username):
            raise ValueError('Username: use 3–32 letters, numbers, underscores or hyphens.')
        if not 8 <= len(password) <= 128:
            raise ValueError('Password must contain 8–128 characters.')
        salt = secrets.token_bytes(32)
        digest = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, ITERATIONS)
        try:
            with self.connect() as db:
                db.execute('INSERT INTO users VALUES (?, ?, ?, ?, ?)', (str(uuid.uuid4()), username, name, salt, digest))
        except sqlite3.IntegrityError:
            raise ValueError('That username is already registered.') from None

    def authenticate(self, username, password):
        if len(password) > 128:
            return None
        with self.connect() as db:
            row = db.execute('SELECT id, username, name, salt, digest FROM users WHERE username=?', (username.strip().lower(),)).fetchone()
        salt = row[3] if row else bytes(32)
        actual = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, ITERATIONS)
        if row and hmac.compare_digest(actual, row[4]):
            return dict(id=row[0], username=row[1], name=row[2])
        return None


class StudentApp(core.FlashMind):
    def __init__(self, root, user, logout_callback):
        self.user = user
        self.logout_callback = logout_callback
        # Existing FlashMind methods resolve this path at runtime.
        # Only one student session runs in this desktop process at a time.
        core.DEFAULT_FILE = DATA / ('student_' + user['id'] + '.json')
        super().__init__(root)
        root.title('Falshcard generator | ' + user['name'])
        self.home = self.frame(self.tabs, core.BG)
        self.tabs.insert(0, self.home, text='Home dashboard')
        self.build_home()
        self.tabs.select(self.home)
        self.tabs.bind('<<NotebookTabChanged>>', lambda e: self.update_home())
        self.update_home()

    def build_home(self):
        top = self.frame(self.home, core.BG)
        top.pack(fill='x', pady=24)
        self.label(top, 'Welcome, ' + self.user['name'], 26, core.ACCENT, True).pack(side='left')
        self.button(top, 'Log out', self.logout).pack(side='right')
        self.label(self.home, 'YOUR PERSONAL LEARNING SPACE  /  @' + self.user['username'], 11, core.MUTED, True).pack(anchor='w')
        self.home_metrics = self.label(self.home, '', 19, core.INK, True)
        self.home_metrics.pack(anchor='w', pady=30)
        actions = self.frame(self.home, core.BG)
        actions.pack(fill='x', pady=8)
        for label, page in [('Study my cards', self.study), ('Take a quiz', self.quiz), ('View statistics', self.insights)]:
            self.button(actions, label, lambda p=page: self.tabs.select(p), True).pack(side='left', padx=(0, 12))
        self.label(self.home, 'RECENT ACTIVITY', 11, core.MUTED, True).pack(anchor='w', pady=(35, 12))
        self.activity = self.label(self.home, '', 13)
        self.activity.pack(anchor='w')
        self.label(self.home, 'Your cards and completed quiz results are saved separately for this account.\nLocal project only: this login does not encrypt your study files.', 11, core.MUTED).pack(anchor='w', pady=30)

    def update_home(self):
        if not hasattr(self, 'home_metrics'):
            return
        total = sum(h['total'] for h in self.history)
        correct = sum(h['correct'] for h in self.history)
        accuracy = correct / total * 100 if total else 0
        self.home_metrics.config(text=f'{len(self.cards)} flashcards     •     {len(self.history)} completed quizzes\n\n{accuracy:.1f}% accuracy     •     {total} questions answered')
        recent = '\n\n'.join(f'{h["date"]} — {h["difficulty"]}: {h["correct"]}/{h["total"]} correct' for h in reversed(self.history[-5:]))
        self.activity.config(text=recent or 'No completed quizzes yet. Add some cards and take your first quiz.')

    def refresh_stats(self):
        super().refresh_stats()
        self.update_home()

    def logout(self):
        if self.queue and not messagebox.askyesno('Log out?', 'Your unfinished quiz will be discarded. Log out?'):
            return
        if self.save(quiet=True):
            self.root.unbind('<Control-s>')
            for widget in self.root.winfo_children():
                widget.destroy()
            self.logout_callback()


class LoginScreen:
    def __init__(self, root, store):
        self.root, self.store = root, store
        self.register_mode = False
        self.failures, self.blocked_until = 0, 0
        self.build()

    def build(self):
        root = self.root
        root.title('Falshcard generator | Sign in')
        root.geometry('800x780')
        root.minsize(740, 740)
        root.configure(bg=core.BG)
        root.protocol('WM_DELETE_WINDOW', root.destroy)
        for widget in root.winfo_children():
            widget.destroy()
        tk.Label(root, text='Falshcard generator', bg=core.BG, fg=core.ACCENT, font=('Segoe UI', 28, 'bold')).pack(pady=(28, 5))
        tk.Label(root, text='Your learning journey starts here.', bg=core.BG, fg=core.MUTED, font=('Segoe UI', 12)).pack(pady=(0, 18))
        panel = tk.Frame(root, bg=core.PANEL, padx=28, pady=22)
        panel.pack(padx=70, fill='x')
        tk.Label(panel, text='Create your student account' if self.register_mode else 'Sign in to your dashboard', bg=core.PANEL, fg=core.INK, font=('Segoe UI', 18, 'bold')).pack(anchor='w', pady=(0, 15))
        self.entries = {}
        fields = [('name', 'Full name')] if self.register_mode else []
        fields += [('username', 'Username'), ('password', 'Password')]
        if self.register_mode:
            fields += [('confirm', 'Confirm password')]
        for key, label in fields:
            tk.Label(panel, text=label, bg=core.PANEL, fg=core.MUTED, font=('Segoe UI', 10)).pack(anchor='w', pady=(8, 4))
            entry = tk.Entry(panel, bg=core.FIELD, fg=core.INK, insertbackground=core.INK, relief='flat', font=('Segoe UI', 12), show='*' if key in ('password', 'confirm') else '')
            entry.pack(fill='x', ipady=8)
            self.entries[key] = entry
            entry.bind('<Return>', lambda e: self.submit())
        self.show_password = tk.BooleanVar(value=False)
        tk.Checkbutton(panel, text='Show password', variable=self.show_password, command=self.toggle_password, bg=core.PANEL, fg=core.MUTED, selectcolor=core.FIELD, activebackground=core.PANEL, activeforeground=core.INK).pack(anchor='w', pady=8)
        tk.Button(panel, text='Create account' if self.register_mode else 'Sign in', command=self.submit, bg=core.ACCENT, fg=core.BG, relief='flat', font=('Segoe UI', 11, 'bold'), pady=10).pack(fill='x', pady=8)
        tk.Button(panel, text='Already registered? Sign in' if self.register_mode else 'New student? Create an account', command=self.toggle_mode, bg=core.PANEL, fg=core.ACCENT, relief='flat', font=('Segoe UI', 10)).pack(pady=5)
        self.message = tk.Label(root, text='Passwords must be 8–128 characters. Accounts stay on this computer.', bg=core.BG, fg=core.MUTED, font=('Segoe UI', 10), wraplength=580)
        self.message.pack(pady=15)
        self.entries['name' if self.register_mode else 'username'].focus_set()

    def toggle_mode(self):
        self.register_mode = not self.register_mode
        self.build()

    def toggle_password(self):
        for key in ('password', 'confirm'):
            if key in self.entries:
                self.entries[key].config(show='' if self.show_password.get() else '*')

    def submit(self):
        if time.monotonic() < self.blocked_until:
            self.message.config(text='Too many failed attempts. Please wait 30 seconds.', fg=core.BAD)
            return
        values = {k: e.get() for k,e in self.entries.items()}
        try:
            if self.register_mode:
                if values['password'] != values['confirm']:
                    raise ValueError('The passwords do not match.')
                self.store.register(values['name'], values['username'], values['password'])
                self.register_mode = False
                self.build()
                self.entries['username'].insert(0, values['username'].strip().lower())
                self.message.config(text='Account created. Sign in with your new credentials.', fg=core.GOOD)
            else:
                user = self.store.authenticate(values['username'], values['password'])
                if not user:
                    self.failures += 1
                    if self.failures >= 5:
                        self.blocked_until = time.monotonic() + 30
                        self.failures = 0
                    self.entries['password'].delete(0, 'end')
                    raise ValueError('Invalid username or password.')
                for widget in self.root.winfo_children():
                    widget.destroy()
                StudentApp(self.root, user, lambda: LoginScreen(self.root, self.store))
        except (ValueError, sqlite3.Error, OSError) as exc:
            self.message.config(text=str(exc), fg=core.BAD)


if __name__ == '__main__':
    root = tk.Tk()
    try:
        store = AccountStore()
        LoginScreen(root, store)
        root.mainloop()
    except (sqlite3.Error, OSError) as exc:
        messagebox.showerror('Cannot open student storage', str(exc))
        root.destroy()
