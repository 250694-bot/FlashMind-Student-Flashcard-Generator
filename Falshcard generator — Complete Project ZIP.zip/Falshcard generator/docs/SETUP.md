# Setup and troubleshooting

Use Python 3.10+ with Tkinter. Run python main.py from the project folder. On Windows, py main.py may work if python is not on PATH; Start-Windows.bat uses python.

If Tkinter is missing, repair your Python installation to include Tcl/Tk. There is no supported pip install for Tkinter. If FlashMind_Pro cannot be imported, ensure both modules and main.py remain together.

If saving fails, move the extracted project to a writable folder. Do not run inside the ZIP. SQLite and JSON files are created under flashmind_students/.

There are no preset usernames or passwords. Forgot a password? No recovery feature is implemented. Keep backups and do not delete your data to troubleshoot without first making a copy.

To transfer existing accounts, copy the entire flashmind_students directory while the application is closed. To transfer only cards, use Export deck and Load file.
