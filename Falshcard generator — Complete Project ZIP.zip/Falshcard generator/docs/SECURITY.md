# Security and privacy

Passwords use PBKDF2-HMAC-SHA256, 600,000 iterations and independent 32-byte random salts. Verification uses constant-time digest comparison. Parameterized SQL is used for account operations. Username validation and uniqueness checks prevent duplicate logins.

The login screen implements a five-failure, 30-second cooldown within its current session only; restarting the app bypasses it. This is not durable rate limiting.

This is a local demonstration, not a secure online service. Study JSON is plaintext. Local access can expose or alter data or the account database. Login is an interface gate, not filesystem isolation; the core module can be run directly. Use operating-system accounts and permissions for sensitive material.

No recovery, email verification, encryption at rest or cloud authentication is implemented. No default credentials, test accounts or student data are shipped in the ZIP.
