# Changes in this package

- Added main.py as the login-first launch entry point.
- Updated visible app name to Falshcard generator as requested.
- Added case-insensitive search for question and answer text.
- Added an editing form with option validation and profile saving.
- Added JSON deck export without credentials or history.
- Expanded the login window to give registration fields more space.
- Included launch instructions, requirements, user guide, report, security notes and tests.
- Preserved account registration, salted password hashing, separate profiles, quizzes and statistics.
