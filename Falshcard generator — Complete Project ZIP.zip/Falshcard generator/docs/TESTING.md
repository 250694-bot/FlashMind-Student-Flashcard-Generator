# Testing checklist

Automated: run python -m unittest discover -s tests -v. This checks syntax, legacy card normalization, quiz option uniqueness, correct-answer presence, custom distractors, insufficient options, registration, invalid login, duplicate accounts and password hashes.

Manual graphical checks (not completed by the automated tests):
1. Register two students and verify separate decks/history.
2. Try an incorrect password and mismatched registration confirmation.
3. Add cards; search, edit, reveal, shuffle and delete.
4. Export a deck and import it into the second account.
5. Run a complete quiz and confirm final score, review window and statistics.
6. Restart an unfinished quiz and verify it is not counted.
7. Log out/log in and confirm saved data.
8. Resize windows and check all controls fit and are readable.

Retain backups before import tests. Do not use real passwords for demonstration.
