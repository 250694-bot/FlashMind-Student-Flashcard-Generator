# User guide

## Login
Register with a name, unique username and password of 8–128 characters. Sign in to reach Home. Keep your password private. Show password is optional.

## Study
Add a question, correct answer, difficulty and optional three distinct wrong answers. Browse or reveal answers. Save with the Save button or Ctrl+S. Search matches question and answer text without case sensitivity; select a result to open it. Edit current card opens a form and saves changes to your profile. Active quiz questions keep their starting snapshot.

## Quiz
Choose a difficulty and start. Select one of four options, check the answer, and advance. Finish the last question to record the attempt. Only completed attempts count. Restart or logout discards an unfinished quiz. Review missed answers in the result window.

## Statistics
Overall accuracy = correct answers / answered questions across completed quizzes × 100. Best quiz is the highest completed quiz percentage. Quiz progress measures completion, not mastery.

## Export/import
Export deck writes questions, answers, options and difficulty to JSON without credentials or history. Load file imports supported JSON and replaces your current deck/history after confirmation. Save first. Do not export private material to a shared location unless you intend to share it.

## Log out
Logout saves the current profile before returning to login. Closing the signed-in window also saves.
