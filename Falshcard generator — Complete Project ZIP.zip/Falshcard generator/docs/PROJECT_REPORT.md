# Falshcard generator — mini-project report

## Objective
Provide a local student workspace for organized revision, multiple-choice practice and saved learning statistics.

## Technology
Python implements logic. Tkinter provides desktop widgets. SQLite stores account identities and password hashes. JSON stores per-student cards and quiz history. Only Python standard-library modules are used.

## Architecture
main.py opens LoginScreen. AccountStore validates registration and verifies credentials. After login, StudentApp extends the core FlashMind class and selects a UUID-based JSON file. Tabs provide Home, Study, Quiz and Statistics. Logout saves and returns to LoginScreen.

## Data model
Accounts: UUID, normalized unique username, display name, random salt, password digest.
Cards: UUID, question, answer, wrong-option list and difficulty.
Completed attempts: timestamp, difficulty filter, total question count and correct count.

## Quiz algorithm
Filter cards by requested difficulty. Build four distinct options from the correct answer, custom distractors and, if needed, other deck answers. Skip ineligible cards. Shuffle questions and options. Accept one checked answer per question. Record history only when the quiz is finished.

## Added enhancements
Search across questions and answers; edit existing cards while retaining their identity; export a shareable deck; unified project entry point and documentation. Login layout has more space for the registration form.

## Scope
Flashcards are manually authored. Difficulty is a card label, not automatically generated question complexity. No learning-effectiveness study or production security audit has been performed.

## Future work
Account recovery, visual charts, accessibility testing, improved distractor quality, cloud sync and a web backend with server-side controls.
