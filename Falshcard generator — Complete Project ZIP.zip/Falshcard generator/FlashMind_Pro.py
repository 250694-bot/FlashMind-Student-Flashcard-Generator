"""FlashMind Pro — run with Python 3: python FlashMind_Pro.py
Uses only the standard library. Requires Python with Tkinter installed.
"""
import json
import random
import uuid
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog
from datetime import datetime

BG, PANEL, FIELD = '#101820', '#1b2935', '#243746'
INK, MUTED, ACCENT, GOOD, BAD = '#f1f5f4', '#aabcc6', '#55c9b0', '#78d6a3', '#ff9292'
DEFAULT_FILE = Path(__file__).resolve().with_name('flashmind_data.json')


def normalize_cards(raw):
    if not isinstance(raw, list):
        raise ValueError('Cards must be a list.')
    result = []
    ids = set()
    for item in raw:
        if not isinstance(item, dict):
            raise ValueError('Each card must be an object.')
        q, a = item.get('question'), item.get('answer')
        if not isinstance(q, str) or not isinstance(a, str) or not q.strip() or not a.strip():
            raise ValueError('Every card needs a question and answer.')
        wrong = item.get('wrong', [])
        if not isinstance(wrong, list) or any(not isinstance(x, str) for x in wrong):
            raise ValueError('Wrong options must be a list of text values.')
        ident = str(item.get('id') or uuid.uuid4())
        if ident in ids:
            ident = str(uuid.uuid4())
        ids.add(ident)
        level = item.get('difficulty', 'Easy')
        if level not in ('Easy', 'Medium', 'Hard'):
            level = 'Easy'
        result.append(dict(id=ident, question=q.strip(), answer=a.strip(),
                           wrong=list(dict.fromkeys(x.strip() for x in wrong if x.strip() and x.strip().casefold() != a.strip().casefold())), difficulty=level))
    return result


def make_options(card, deck, rng=random):
    """Prefer author-supplied distractors; otherwise borrow distinct deck answers."""
    correct = card['answer']
    pool = card.get('wrong', []) + [c['answer'] for c in deck if c['id'] != card['id']]
    unique, seen = [], {correct.casefold()}
    for value in pool:
        if value.casefold() not in seen:
            seen.add(value.casefold())
            unique.append(value)
    if len(unique) < 3:
        return None
    options = [correct] + rng.sample(unique, 3)
    rng.shuffle(options)
    return options


class FlashMind:
    def __init__(self, root):
        self.root = root
        self.cards, self.history = [], []
        self.index, self.revealed = 0, False
        self.queue, self.position, self.responses = [], 0, []
        self.checked, self.selected = False, tk.IntVar(value=-1)
        root.title('Falshcard generator | Study • Quiz • Insights')
        root.geometry('1180x820')
        root.minsize(1000, 760)
        root.configure(bg=BG)
        style = ttk.Style(root)
        style.theme_use('clam')
        style.configure('TNotebook', background=BG, borderwidth=0)
        style.configure('TNotebook.Tab', background=PANEL, foreground=INK, padding=(24, 12), font=('Segoe UI', 11, 'bold'))
        style.map('TNotebook.Tab', background=[('selected', ACCENT)], foreground=[('selected', BG)])
        style.configure('TProgressbar', troughcolor=FIELD, background=ACCENT)
        header = self.frame(root, BG)
        header.pack(fill='x', padx=28, pady=(20, 12))
        self.label(header, 'Falshcard generator', 23, ACCENT, True).pack(side='left')
        self.label(header, 'PRO  /  LEARN WITH PURPOSE', 10, MUTED).pack(side='left', padx=20)
        self.deck_count = self.label(header, '0 cards', 11)
        self.deck_count.pack(side='right')
        self.tabs = ttk.Notebook(root)
        self.tabs.pack(fill='both', expand=True, padx=28)
        self.study, self.quiz, self.insights = [self.frame(self.tabs, BG) for _ in range(3)]
        for f, name in zip((self.study, self.quiz, self.insights), ('Study studio', 'Quiz mode', 'Statistics')):
            self.tabs.add(f, text=name)
        self.build_study()
        self.build_quiz()
        self.build_stats()
        extras = self.frame(root, BG)
        extras.pack(fill='x', padx=28, pady=(10, 0))
        for title, action in [('Search cards', self.search_cards), ('Edit current card', self.edit_card), ('Export deck', self.export_deck)]:
            self.button(extras, title, action).pack(side='left', padx=(0, 10))
        self.status = self.label(root, 'Ready. Add cards or try the demo deck.', 10, MUTED)
        self.status.pack(fill='x', padx=28, pady=12)
        root.bind('<Control-s>', lambda e: self.save())
        root.protocol('WM_DELETE_WINDOW', self.close)
        if DEFAULT_FILE.exists():
            self.load(DEFAULT_FILE, quiet=True)
        self.refresh()

    def frame(self, parent, color=PANEL):
        return tk.Frame(parent, bg=color)

    def label(self, parent, text='', size=12, color=INK, bold=False):
        return tk.Label(parent, text=text, bg=parent.cget('bg'), fg=color,
                        font=('Segoe UI', size, 'bold' if bold else 'normal'), justify='left', wraplength=650)

    def button(self, parent, text, command, primary=False):
        return tk.Button(parent, text=text, command=command, bg=ACCENT if primary else FIELD,
                         fg=BG if primary else INK, activebackground=GOOD,
                         activeforeground=BG, font=('Segoe UI', 10, 'bold'), relief='flat',
                         bd=0, padx=14, pady=9, cursor='hand2', wraplength=600)

    def build_study(self):
        self.study.columnconfigure(1, weight=1)
        self.study.rowconfigure(0, weight=1)
        left = self.frame(self.study)
        left.grid(row=0, column=0, sticky='nsew', padx=(0, 18), pady=18)
        self.label(left, 'Create a card', 19, INK, True).pack(anchor='w', padx=20, pady=(18, 12))
        self.fields = {}
        for key, title, height in [('question', 'QUESTION', 3), ('answer', 'CORRECT ANSWER', 2), ('wrong', '3 WRONG OPTIONS (one per line, optional)', 3)]:
            self.label(left, title, 9, MUTED, True).pack(anchor='w', padx=20, pady=(8, 5))
            box = tk.Text(left, width=32, height=height, bg=FIELD, fg=INK, insertbackground=INK,
                          font=('Segoe UI', 11), relief='flat', padx=10, pady=8, wrap='word')
            box.pack(fill='x', padx=20)
            self.fields[key] = box
        self.level = tk.StringVar(value='Easy')
        self.label(left, 'DIFFICULTY', 9, MUTED, True).pack(anchor='w', padx=20, pady=(12, 5))
        ttk.Combobox(left, textvariable=self.level, values=['Easy', 'Medium', 'Hard'], state='readonly').pack(fill='x', padx=20)
        self.button(left, '+ Add flashcard', self.add_card, True).pack(fill='x', padx=20, pady=14)
        self.button(left, 'Try demo deck', self.demo).pack(fill='x', padx=20, pady=(0, 15))
        right = self.frame(self.study, BG)
        right.grid(row=0, column=1, sticky='nsew', pady=18)
        self.card_tag = self.label(right, 'YOUR STUDY DECK', 10, ACCENT, True)
        self.card_tag.pack(anchor='w', pady=12)
        face = self.frame(right)
        face.pack(fill='both', expand=True)
        self.q_label = self.label(face, '', 24, INK, True)
        self.q_label.pack(fill='both', expand=True, padx=24, pady=24)
        self.a_label = self.label(face, '', 15, ACCENT)
        self.a_label.pack(fill='both', expand=True, padx=24, pady=18)
        self.card_progress = ttk.Progressbar(right, maximum=100)
        self.card_progress.pack(fill='x', pady=12)
        nav = self.frame(right, BG)
        nav.pack(pady=6)
        for text, fn in [('← Previous', lambda: self.move(-1)), ('Show / hide answer', self.flip), ('Next →', lambda: self.move(1))]:
            self.button(nav, text, fn).pack(side='left', padx=4)
        tools = self.frame(right, BG)
        tools.pack(pady=10)
        for text, fn in [('Shuffle', self.shuffle), ('Delete', self.delete), ('Save', self.save), ('Load file', self.choose_load)]:
            self.button(tools, text, fn).pack(side='left', padx=4)

    def build_quiz(self):
        setup = self.frame(self.quiz, BG)
        setup.pack(fill='x', pady=18)
        self.label(setup, 'Challenge your memory', 21, INK, True).pack(side='left')
        self.filter = tk.StringVar(value='All')
        ttk.Combobox(setup, textvariable=self.filter, values=['All', 'Easy', 'Medium', 'Hard'], state='readonly', width=10).pack(side='right', padx=10)
        self.button(setup, 'Start / restart quiz', self.start_quiz, True).pack(side='right')
        self.quiz_info = self.label(self.quiz, 'Choose a difficulty and start a quiz.', 12, MUTED)
        self.quiz_info.pack(anchor='w', pady=5)
        self.quiz_progress = ttk.Progressbar(self.quiz, maximum=100)
        self.quiz_progress.pack(fill='x', pady=10)
        self.quiz_question = self.label(self.quiz, 'Four choices. One correct answer.', 22, INK, True)
        self.quiz_question.pack(fill='x', padx=12, pady=18)
        self.option_buttons = []
        for i in range(4):
            rb = tk.Radiobutton(self.quiz, text='', variable=self.selected, value=i, bg=PANEL, fg=INK,
                                selectcolor=FIELD, activebackground=FIELD, activeforeground=INK,
                                font=('Segoe UI', 13), anchor='w', justify='left', wraplength=950,
                                indicatoron=False, relief='flat', padx=18, pady=13, cursor='hand2')
            rb.pack(fill='x', pady=5)
            rb.configure(state='disabled')
            self.option_buttons.append(rb)
        self.feedback = self.label(self.quiz, '', 13, ACCENT, True)
        self.feedback.pack(fill='x', pady=14)
        controls = self.frame(self.quiz, BG)
        controls.pack(fill='x')
        self.submit = self.button(controls, 'Check answer', self.check_answer, True)
        self.submit.pack(side='left')
        self.advance = self.button(controls, 'Next question →', self.next_question)
        self.advance.pack(side='left', padx=12)
        self.submit.config(state='disabled')
        self.advance.config(state='disabled')

    def build_stats(self):
        self.label(self.insights, 'Your learning, measured', 23, INK, True).pack(anchor='w', pady=22)
        self.metrics = self.label(self.insights, '', 17, ACCENT, True)
        self.metrics.pack(anchor='w', pady=10)
        self.label(self.insights, 'RECENT COMPLETED QUIZZES', 10, MUTED, True).pack(anchor='w', pady=(24, 10))
        self.history_box = tk.Text(self.insights, height=14, bg=PANEL, fg=INK, font=('Consolas', 11), relief='flat', padx=18, pady=15, wrap='word')
        self.history_box.pack(fill='both', expand=True, pady=(0, 18))

    def notify(self, text):
        self.status.config(text=text)

    def refresh(self):
        n = len(self.cards)
        self.deck_count.config(text=f'{n} flashcards')
        if n:
            self.index %= n
            c = self.cards[self.index]
            self.card_tag.config(text=f'CARD {self.index + 1} / {n}   •   {c["difficulty"].upper()}')
            self.q_label.config(text=c['question'])
            self.a_label.config(text=c['answer'] if self.revealed else 'Use Show / hide answer to reveal the answer.')
            self.card_progress['value'] = (self.index + 1) / n * 100
        else:
            self.q_label.config(text='Make room for a new idea.')
            self.a_label.config(text='Add your first flashcard, or load the demo deck.')
            self.card_tag.config(text='EMPTY DECK')
            self.card_progress['value'] = 0
        self.refresh_stats()

    def add_card(self):
        q, a = [self.fields[k].get('1.0', 'end').strip() for k in ('question', 'answer')]
        wrong = [x.strip() for x in self.fields['wrong'].get('1.0', 'end').splitlines() if x.strip()]
        if not q or not a:
            messagebox.showwarning('Missing information', 'Enter a question and its correct answer.')
            return
        if wrong and (len(wrong) != 3 or len({x.casefold() for x in wrong + [a]}) != 4):
            messagebox.showwarning('Check options', 'Enter exactly 3 distinct wrong options, different from the correct answer, or leave options blank.')
            return
        self.cards.append(dict(id=str(uuid.uuid4()), question=q, answer=a, wrong=wrong, difficulty=self.level.get()))
        self.index = len(self.cards) - 1
        self.revealed = False
        for field in self.fields.values():
            field.delete('1.0', 'end')
        self.refresh()
        self.notify('Flashcard added. Press Ctrl+S to save your deck.')

    def move(self, step):
        if self.cards:
            self.index = (self.index + step) % len(self.cards)
            self.revealed = False
            self.refresh()

    def flip(self):
        self.revealed = not self.revealed
        self.refresh()

    def shuffle(self):
        random.shuffle(self.cards)
        self.index, self.revealed = 0, False
        self.refresh()

    def delete(self):
        if self.cards and messagebox.askyesno('Delete card', 'Delete this flashcard?'):
            self.cards.pop(self.index)
            self.revealed = False
            self.refresh()

    def save(self, quiet=False):
        try:
            temporary = DEFAULT_FILE.with_suffix('.tmp')
            temporary.write_text(json.dumps({'version': 1, 'cards': self.cards, 'history': self.history}, ensure_ascii=False, indent=2), encoding='utf-8')
            temporary.replace(DEFAULT_FILE)
            if not quiet:
                self.notify(f'Saved cards and statistics to {DEFAULT_FILE.name}.')
            return True
        except OSError as exc:
            messagebox.showerror('Save failed', str(exc))
            return False

    def choose_load(self):
        p = filedialog.askopenfilename(title='Load FlashMind or legacy flashcards JSON', filetypes=[('JSON files', '*.json')])
        if p and messagebox.askyesno('Replace current deck?', 'Loading replaces the current deck. Save it first if needed. Continue?'):
            self.load(Path(p))

    def load(self, path, quiet=False):
        try:
            raw = json.loads(path.read_text(encoding='utf-8-sig'))
            cards = normalize_cards(raw if isinstance(raw, list) else raw['cards'])
            history = [] if isinstance(raw, list) else raw.get('history', [])
            if not isinstance(history, list):
                raise ValueError('Invalid quiz history.')
            for h in history:
                if not isinstance(h, dict) or not isinstance(h.get('total'), int) or not isinstance(h.get('correct'), int) or not 0 <= h['correct'] <= h['total'] or h['total'] <= 0 or not isinstance(h.get('date'), str) or not isinstance(h.get('difficulty'), str):
                    raise ValueError('Invalid quiz history entry.')
            self.cards, self.history = cards, history
            self.index, self.revealed = 0, False
            self.cancel_quiz()
            self.refresh()
            if not quiet:
                self.notify(f'Loaded {len(cards)} cards. Legacy question/answer files are supported.')
        except (OSError, ValueError, KeyError, TypeError) as exc:
            messagebox.showerror('Cannot load file', str(exc))

    def cancel_quiz(self):
        self.queue = []
        self.submit.config(state='disabled')
        self.advance.config(state='disabled')
        for b in self.option_buttons:
            b.config(state='disabled', text='', bg=PANEL)
        self.quiz_question.config(text='Start a new quiz with your deck.')
        self.feedback.config(text='')
        self.quiz_progress['value'] = 0

    def start_quiz(self):
        if self.queue and not messagebox.askyesno('Restart quiz?', 'Discard the unfinished quiz and start again?'):
            return
        candidates = [dict(c) for c in self.cards if self.filter.get() == 'All' or c['difficulty'] == self.filter.get()]
        queue = []
        for c in candidates:
            options = make_options(c, self.cards)
            if options:
                c['options'] = options
                queue.append(c)
        if not queue:
            messagebox.showinfo('More options needed', 'Add 3 wrong options to a card, or create cards with at least 4 distinct answers. No eligible questions were found.')
            return
        random.shuffle(queue)
        self.queue, self.position, self.responses = queue, 0, []
        self.quiz_level = self.filter.get()
        self.skipped = len(candidates) - len(queue)
        self.show_question()

    def show_question(self):
        self.checked = False
        self.selected.set(-1)
        c = self.queue[self.position]
        self.quiz_info.config(text=f'Question {self.position + 1} of {len(self.queue)} • {self.quiz_level} • Score {sum(r["correct"] for r in self.responses)} • {self.skipped} ineligible cards skipped')
        self.quiz_question.config(text=c['question'])
        self.quiz_progress['value'] = self.position / len(self.queue) * 100
        self.feedback.config(text='Choose an option, then check your answer.', fg=MUTED)
        for i, b in enumerate(self.option_buttons):
            b.config(text=f'{chr(65+i)}.  {c["options"][i]}', state='normal', bg=PANEL, fg=INK)
        self.submit.config(state='normal')
        self.advance.config(state='disabled', text='Finish quiz' if self.position == len(self.queue)-1 else 'Next question →')

    def check_answer(self):
        if not self.queue or self.checked:
            return
        selected = self.selected.get()
        if selected < 0:
            self.feedback.config(text='Select an answer first.', fg=BAD)
            return
        card = self.queue[self.position]
        correct = card['options'][selected] == card['answer']
        self.responses.append(dict(question=card['question'], answer=card['answer'], chosen=card['options'][selected], correct=correct))
        self.checked = True
        for i, b in enumerate(self.option_buttons):
            b.config(state='disabled', disabledforeground=INK)
            if card['options'][i] == card['answer']:
                b.config(bg='#235441')
            elif i == selected:
                b.config(bg='#643c42')
        self.feedback.config(text='Correct! Well done.' if correct else f'Not quite. Correct answer: {card["answer"]}', fg=GOOD if correct else BAD)
        self.submit.config(state='disabled')
        self.advance.config(state='normal')
        self.quiz_progress['value'] = len(self.responses) / len(self.queue) * 100

    def next_question(self):
        if not self.queue or not self.checked:
            return
        if self.position + 1 < len(self.queue):
            self.position += 1
            self.show_question()
            return
        total = len(self.responses)
        correct = sum(r['correct'] for r in self.responses)
        self.history.append(dict(date=datetime.now().strftime('%Y-%m-%d %H:%M'), difficulty=self.quiz_level, total=total, correct=correct))
        self.queue = []
        self.submit.config(state='disabled')
        self.advance.config(state='disabled')
        self.quiz_question.config(text=f'Quiz complete!  {correct} / {total}  •  {correct/total:.0%} accuracy')
        mistakes = [r for r in self.responses if not r['correct']]
        self.feedback.config(text='Excellent work. All answers correct!' if not mistakes else f'Review {len(mistakes)} missed question(s). Results are recorded in Statistics.', fg=ACCENT)
        self.refresh_stats()
        self.save(quiet=True)
        if mistakes:
            window = tk.Toplevel(self.root)
            window.title('Review missed questions')
            window.geometry('700x450')
            text = tk.Text(window, wrap='word', bg=PANEL, fg=INK, font=('Segoe UI', 12), padx=20, pady=20)
            text.pack(fill='both', expand=True)
            for r in mistakes:
                text.insert('end', f'{r["question"]}\nYour choice: {r["chosen"]}\nCorrect: {r["answer"]}\n\n')
            text.config(state='disabled')

    def refresh_stats(self):
        attempts = len(self.history)
        total = sum(h['total'] for h in self.history)
        correct = sum(h['correct'] for h in self.history)
        accuracy = correct / total * 100 if total else 0
        best = max((h['correct']/h['total']*100 for h in self.history), default=0)
        self.metrics.config(text=f'{len(self.cards)} cards     |     {attempts} completed quizzes\n\n{total} questions answered     |     {accuracy:.1f}% overall accuracy\n\n{correct} correct answers     |     {best:.1f}% best quiz')
        self.history_box.config(state='normal')
        self.history_box.delete('1.0', 'end')
        self.history_box.insert('end', 'No completed quizzes yet. Finish a quiz to see your results here.\n' if not self.history else '')
        for h in reversed(self.history[-30:]):
            self.history_box.insert('end', f'{h["date"]}  |  {h["difficulty"]:6}  |  {h["correct"]}/{h["total"]}  |  {h["correct"]/h["total"]:.0%}\n')
        self.history_box.config(state='disabled')

    def demo(self):
        sample = [
            ('Which component executes program instructions?', 'CPU', ['Keyboard', 'Monitor', 'Hard disk'], 'Easy'),
            ('Which memory is volatile?', 'RAM', ['ROM', 'SSD', 'DVD'], 'Easy'),
            ('What does ALU stand for?', 'Arithmetic Logic Unit', ['Automatic Loading Unit', 'Address Lookup Utility', 'Analog Logic Utility'], 'Medium'),
            ('Which scheduling algorithm uses a fixed time quantum?', 'Round Robin', ['First Come First Served', 'Shortest Job First', 'Non-preemptive Priority'], 'Medium'),
            ('What is the decimal value of binary 1010?', '10', ['8', '12', '14'], 'Easy'),
            ('Which structure follows LIFO?', 'Stack', ['Queue', 'Heap', 'Graph'], 'Easy'),
            ('Which cache mapping permits a block in any cache line?', 'Fully associative', ['Direct mapped', 'Two-way set associative only', 'Sequential mapped'], 'Hard'),
        ]
        if self.cards and not messagebox.askyesno('Add demo cards?', 'Append 7 demo cards to your existing deck?'):
            return
        self.cards.extend(dict(id=str(uuid.uuid4()), question=q, answer=a, wrong=w, difficulty=d) for q,a,w,d in sample)
        self.refresh()
        self.notify('Demo cards added. Open Quiz mode to try them.')


    def search_cards(self):
        query = simpledialog.askstring('Search cards', 'Search question or answer:', parent=self.root)
        if query is None:
            return
        matches = [(i, c) for i, c in enumerate(self.cards) if query.strip().casefold() in (c['question'] + ' ' + c['answer']).casefold()]
        if not matches:
            messagebox.showinfo('No matches', 'No cards matched your search.')
            return
        window = tk.Toplevel(self.root)
        window.title('Search results')
        window.geometry('700x380')
        results = tk.Listbox(window, bg=PANEL, fg=INK, selectbackground=ACCENT, selectforeground=BG, font=('Segoe UI', 12))
        results.pack(fill='both', expand=True, padx=15, pady=15)
        for _, c in matches:
            results.insert('end', c['difficulty'] + ' | ' + c['question'])
        def open_card():
            selected = results.curselection()
            if selected:
                self.index = matches[selected[0]][0]
                self.revealed = False
                self.refresh()
                self.tabs.select(self.study)
                window.destroy()
        self.button(window, 'Open selected card', open_card, True).pack(pady=(0, 15))
        results.bind('<Double-Button-1>', lambda event: open_card())

    def edit_card(self):
        if not self.cards:
            messagebox.showinfo('No cards', 'Add a card first.')
            return
        ident = self.cards[self.index]['id']
        card = dict(self.cards[self.index])
        window = tk.Toplevel(self.root)
        window.title('Edit flashcard')
        window.geometry('620x630')
        window.configure(bg=PANEL)
        window.transient(self.root)
        window.grab_set()
        inputs = {}
        for key, title in [('question', 'Question'), ('answer', 'Correct answer'), ('wrong', 'Three wrong options (one per line, or leave blank)')]:
            self.label(window, title, 11, MUTED).pack(anchor='w', padx=20, pady=(12, 4))
            widget = tk.Text(window, height=3, bg=FIELD, fg=INK, insertbackground=INK, font=('Segoe UI', 11), wrap='word')
            widget.pack(fill='x', padx=20)
            widget.insert('1.0', '\n'.join(card.get('wrong', [])) if key == 'wrong' else card[key])
            inputs[key] = widget
        difficulty = tk.StringVar(value=card['difficulty'])
        ttk.Combobox(window, textvariable=difficulty, values=['Easy', 'Medium', 'Hard'], state='readonly').pack(fill='x', padx=20, pady=15)
        def apply():
            q, a = [inputs[k].get('1.0', 'end').strip() for k in ('question', 'answer')]
            wrong = [v.strip() for v in inputs['wrong'].get('1.0', 'end').splitlines() if v.strip()]
            if not q or not a or (wrong and (len(wrong) != 3 or len({v.casefold() for v in wrong + [a]}) != 4)):
                messagebox.showwarning('Invalid card', 'Enter a question and answer, plus either zero or three distinct wrong options.', parent=window)
                return
            for i, existing in enumerate(self.cards):
                if existing['id'] == ident:
                    self.cards[i] = dict(id=ident, question=q, answer=a, wrong=wrong, difficulty=difficulty.get())
                    self.index = i
                    break
            self.revealed = False
            self.refresh()
            self.save(quiet=True)
            window.destroy()
            self.notify('Card updated. Active quiz questions remain unchanged until the next quiz.')
        self.button(window, 'Save changes', apply, True).pack(pady=10)

    def export_deck(self):
        if not self.cards:
            messagebox.showinfo('Empty deck', 'Add cards before exporting.')
            return
        destination = filedialog.asksaveasfilename(title='Export study deck', defaultextension='.json', initialfile='study_deck.json', filetypes=[('JSON deck', '*.json')])
        if not destination:
            return
        try:
            Path(destination).write_text(json.dumps(self.cards, ensure_ascii=False, indent=2), encoding='utf-8')
            self.notify('Deck exported. Account credentials and quiz history were not included.')
        except OSError as exc:
            messagebox.showerror('Export failed', str(exc))

    def close(self):
        if self.save(quiet=True) or messagebox.askyesno('Exit without saving?', 'Saving failed. Exit anyway?'):
            self.root.destroy()


if __name__ == '__main__':
    root = tk.Tk()
    app = FlashMind(root)
    root.mainloop()
